/*
 * Teran.h
 *
 *  Created on: Aug 28, 2019
 *      Author: Gus Teran
 */

#ifndef TERAN_H_
#define TERAN_H_
#include "Search.h"



#endif /* TERAN_H_ */
