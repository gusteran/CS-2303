/*
 * Teran.h
 *
 *  Created on: Sep 25, 2019
 *      Author: gustt
 */

#ifndef TERAN_H_
#define TERAN_H_
#include "Checker.h"

#endif /* TERAN_H_ */
