/*
 * Layout.c
 *
 *  Created on: Aug 27, 2019
 *      Author: gustt
 */

#include "Layout.h"

int countRooms(Layout layout){
	return sizeof(layout.rooms) / sizeof(Room);
}

Room getFirstRoom(Layout layout){
	Room room = layout.rooms[0];
	return room;
}


