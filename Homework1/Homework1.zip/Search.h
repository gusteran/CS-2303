/*
 * Search.h
 *
 *  Created on: Aug 27, 2019
 *      Author: gustt
 */

#ifndef SEARCH_H_
#define SEARCH_H_
#include "House.h", "Room.h"


#endif /* SEARCH_H_ */
