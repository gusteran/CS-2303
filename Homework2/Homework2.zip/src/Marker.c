/*
 * Marker.c
 *
 *  Created on: Sep 9, 2019
 *      Author: gustt
 */

#include "Marker.h"

void printMarker(Marker marker){
	printf("X: %d\tY: %d", marker.x, marker.y);
}
