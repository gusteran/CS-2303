/*
 * Marker.h
 *
 *  Created on: Sep 9, 2019
 *      Author: gustt
 */

#ifndef MARKER_H_
#define MARKER_H_

typedef struct{
	int x;
	int y;
} Marker;

void printMarker(Marker marker);

#endif /* MARKER_H_ */
