/*
 * production.h
 *
 *  Created on: Aug 27, 2019
 *      Author: gustt
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include "BoardState.h"

void moveIterations(int count);

bool production(int argc, char* argv[]);

#endif /* PRODUCTION_H_ */
