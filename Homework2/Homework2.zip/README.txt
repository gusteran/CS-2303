Here is my Homework 2, just a few notes

The code is included in the src file

The tests are a series of screenshots in the test folder

The output is shown in the two text files, I found it easier to provide
text files as opposed to screenshotting every iteration

The sequence diagram is the layout.jpg

I took up my own style with the presentation of this output by displaying
the array as chars in order to use characters to create a path with arrows
behind the marker as it moves around the board. I did this instead of using numbers
to show the location of the marker as I thought it looked better stylistically.
I did not separate the cells but instead provide an edge to the board and 
leave the inside as blank characters by default. I display what move occured at each
iteration. My marker is the @ symbol