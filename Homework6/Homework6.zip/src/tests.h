/*
 * tests.h
 *
 *  Created on: Oct 2, 2019
 *      Author: gustt
 */

#ifndef TESTS_H_
#define TESTS_H_
#include "Board.h"

bool tests();
bool printBoardTest();
bool printBoardTest2();
bool shotTest1();
bool shotTest2();
bool shotTest3();
bool randPlaceTest();
bool manualPlaceTest();

#endif /* TESTS_H_ */
