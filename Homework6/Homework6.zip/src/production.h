/*
 * production.h
 *
 *  Created on: Oct 2, 2019
 *      Author: gustt
 */

#ifndef PRODUCTION_H_
#define PRODUCTION_H_
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "Game.h"

bool production(int argc, char* argv[]);

#endif /* PRODUCTION_H_ */
