/*
 * Teran.h
 *
 *  Created on: Oct 2, 2019
 *      Author: gustt
 */

#ifndef TERAN_H_
#define TERAN_H_

class Homework6 {
};

#endif /* TERAN_H_ */
