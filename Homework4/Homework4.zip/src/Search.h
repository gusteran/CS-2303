/*
 * Search.h
 *
 *  Created on: Aug 27, 2019
 *      Author: gustt
 */

#ifndef SEARCH_H_
#define SEARCH_H_
#include "House.h"


void searchForTreasure(House house, Search *search);

double countTreasure(House house, Search search);

#endif /* SEARCH_H_ */
